const CONTACT = {
  phone: "(51) 99568-4319",
  whatsappLink: "https://wa.me/5551995684319",
  email: "ferrari84.daniela@gmail.com",
  instagram: "https://www.instagram.com/ferrariefrohlichadv",
  facebook: "https://www.facebook.com"
};

export default function Home() {
  return (
    <div className="bg-black text-white min-h-screen font-sans" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1503736334956-4c8f8e92946d')", backgroundSize: "cover", backgroundRepeat: "no-repeat", backgroundPosition: "center" }}>
      <header className="p-6 shadow-md bg-gradient-to-r from-yellow-700 to-yellow-400 text-black">
        <h1 className="text-3xl font-bold">Ferrari & Fröhlich Advocacia</h1>
        <p className="text-sm">Especializadas em Direito de Trânsito</p>
      </header>

      <main className="space-y-16 bg-black bg-opacity-80">
        <section className="relative bg-cover bg-center h-screen flex items-center justify-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1593980637334-e98c9d4f80f5')" }}>
          <div className="bg-black bg-opacity-70 p-10 rounded-xl text-center">
            <h2 className="text-3xl font-bold text-gold">Defendemos seu direito de dirigir</h2>
            <p className="mt-4 text-gray-300 text-lg">Multas, Suspensão da CNH, Acidentes de Trânsito e mais.</p>
            <a
              href={CONTACT.whatsappLink}
              className="inline-block mt-6 px-6 py-3 bg-green-500 text-white rounded-xl font-semibold shadow-lg hover:bg-green-400 flex items-center justify-center gap-2"
            >
              <span>📱</span> Atendimento pelo WhatsApp
            </a>
          </div>
        </section>

        <section className="p-6 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-gold mb-4">Fale Conosco</h3>
          <form className="space-y-4">
            <input type="text" placeholder="Seu nome" className="w-full px-4 py-2 rounded bg-gray-800 text-white placeholder-gray-500" />
            <input type="tel" placeholder="Telefone para contato" className="w-full px-4 py-2 rounded bg-gray-800 text-white placeholder-gray-500" />
            <textarea placeholder="Descreva brevemente seu caso" className="w-full px-4 py-2 rounded bg-gray-800 text-white placeholder-gray-500 h-32"></textarea>
            <button type="submit" className="px-6 py-3 bg-gold text-black font-semibold rounded shadow hover:bg-yellow-400">Enviar</button>
          </form>
          <div className="mt-6">
            <a
              href={CONTACT.whatsappLink}
              className="inline-block px-6 py-3 bg-green-500 text-white rounded-xl font-semibold shadow-lg hover:bg-green-400 flex items-center justify-center gap-2"
            >
              <span>📱</span> Fale pelo WhatsApp
            </a>
          </div>
        </section>
      </main>

      <footer className="p-6 text-center text-gray-500 border-t border-gray-700">
        <div className="mb-2">
          <a href={CONTACT.instagram} className="mx-2 hover:text-gold">Instagram</a>
          <a href={CONTACT.facebook} className="mx-2 hover:text-gold">Facebook</a>
          <a href={`mailto:${CONTACT.email}`} className="mx-2 hover:text-gold">Email</a>
        </div>
        &copy; 2025 Ferrari & Fröhlich Advocacia. Todos os direitos reservados.
      </footer>
    </div>
  );
}
